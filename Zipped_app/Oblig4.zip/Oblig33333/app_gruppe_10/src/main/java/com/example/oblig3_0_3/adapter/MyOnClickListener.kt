package com.example.oblig3_0_3.adapter

interface MyOnClickListener {
    fun onClick(position: Int)


}