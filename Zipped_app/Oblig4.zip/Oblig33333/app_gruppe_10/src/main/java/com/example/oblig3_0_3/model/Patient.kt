package com.example.oblig3_0_3.model;


data class Patient(

    val patientId: String,
    var patientName: String,
    var symptoms: String,
    var departmentId: String,



    )
