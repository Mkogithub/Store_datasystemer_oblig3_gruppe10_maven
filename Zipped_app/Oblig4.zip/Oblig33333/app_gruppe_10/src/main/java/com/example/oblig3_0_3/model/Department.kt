package com.example.oblig3_0_3.model

data class Department (
    val departmentId: String,
    val departmentName: String
        )