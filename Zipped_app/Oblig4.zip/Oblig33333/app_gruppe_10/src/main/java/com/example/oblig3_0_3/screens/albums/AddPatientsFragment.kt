package com.example.oblig3_0_3.screens.albums

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import com.example.oblig3_0_3.databinding.FragmentAddPatientBinding
import com.example.oblig3_0_3.model.Patient
import com.example.oblig3_0_3.screens.albums.repository.Repository
import kotlinx.coroutines.launch

class AddPatientsFragment : Fragment() {
    private var _binding: FragmentAddPatientBinding? = null
    private val binding get() = _binding!!
    private val args: AddPatientsFragmentArgs by navArgs()
    private lateinit var repository: Repository



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddPatientBinding.inflate(inflater, container, false)


        // Initialize repository and UI elements
        repository = Repository()

        val departmentId = StringBuilder("d" + args.departmentId).toString()
        Log.d("response", departmentId)
        // Add click listener to Add button
        binding.add.setOnClickListener {
            val name = binding.userName.text.toString().trim()
            val symptoms = binding.userSym.text.toString().trim()




            Log.d("response", "onCreateView: $name $symptoms")

            if (name.isNotEmpty() && symptoms.isNotEmpty()) {
                val newPatient = Patient(patientId = "", patientName = name, symptoms = symptoms, departmentId=departmentId)
                addNewPatient(newPatient)
            } else {
                Toast.makeText(requireContext(), "Please enter Name and Symptoms", Toast.LENGTH_SHORT).show()
            }
        }
        Log.d("response", "onCreateView: lol")


        return binding.root
    }

    private fun addNewPatient(patient: Patient) {
        // Call addPatient() function from Repository class to add new patient
        lifecycleScope.launch {
            val response = repository.addPatient(patient)
            if (response.isSuccessful && response.body() != null) {
                Toast.makeText(requireContext(), "New patient added successfully", Toast.LENGTH_SHORT).show()


            } else {
                Toast.makeText(requireContext(), "Failed to add new patient", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
