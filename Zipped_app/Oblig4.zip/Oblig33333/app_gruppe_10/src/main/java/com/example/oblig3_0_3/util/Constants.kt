package com.example.oblig3_0_3.util

class Constants {

    companion object {

        //your computers ipv4 address, or 10.0.0.2
        const val BASE_URL = "http://158.39.116.209:8080/api/"


    }
}