package com.example.oblig3_0_3.model

data class PatientResponse (
    val id: String,
    val result: String
)