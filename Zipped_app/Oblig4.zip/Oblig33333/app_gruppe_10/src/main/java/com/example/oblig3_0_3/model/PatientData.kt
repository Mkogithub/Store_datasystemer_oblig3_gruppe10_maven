package com.example.oblig3_0_3.model

data class PatientData (
    val patientName: String,
    val patientSymptom: String
    )