package com.example.oblig3_0_3.screens.photos

import android.content.DialogInterface
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.oblig3_0_3.databinding.FragmentPhotoBinding
import com.example.oblig3_0_3.model.Patient
import com.example.oblig3_0_3.screens.albums.repository.Repository


class PhotoFragment : Fragment() {

    val args: PhotoFragmentArgs by navArgs()

    private var _binding: FragmentPhotoBinding? = null
    private val binding get() = _binding!!


    private lateinit var viewModel: PhotoViewModel


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            (activity as AppCompatActivity?)!!.supportActionBar!!.hide()
        }

        val thumbnailId = args.thumbnailId

        _binding = FragmentPhotoBinding.inflate(inflater, container, false)


        val repository = Repository()
        val viewModelFactory = PhotoViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory)[PhotoViewModel::class.java]


        viewModel.myCustomPhoto.observe(viewLifecycleOwner, Observer { response ->
            if (response!!.isSuccessful) {

                if (binding.editTitle!!.text.toString().isEmpty()) {
                    viewModel.getCustomTitle(response.body()!!.title)
                }
                else {
                    viewModel.getCustomTitle(response.body()!!.title)
                    response.body()!!.title = binding.editTitle!!.text.toString()
                }


                Log.d("Response", response.body().toString())
                binding.photoTitle!!.text = response.body()?.title
                Log.d("Response", response.code().toString())
                response.body()?.let { Log.d("Response", it.thumbnailUrl.plus(".jpg")) }
                viewModel.getCustomTitle(response.body()!!.title)






                    Log.d("Response", response.code().toString())
                    Log.d("Response", response.body().toString())
                    Log.d("Response", response.message().toString())
                }




        })

        binding.changeTitleButton?.setOnClickListener {
            var name = binding.editPatient?.text.toString()
            var symp = binding.editSymp?.text.toString()

            Log.d("name", name)
            Log.d("symptom", symp)

            if (name.isNotEmpty() && symp.isNotEmpty()) {
                val updatePatient = Patient(patientId = thumbnailId, patientName = name, symptoms = symp, departmentId = args.departmentId )
                viewModel.updatePatient(thumbnailId,updatePatient)
            } else {
                Toast.makeText(requireContext(), "Please enter Name and Symptoms", Toast.LENGTH_SHORT).show()
            }
        }

        binding.deletePhoto!!.setOnClickListener {
            val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
            builder.setCancelable(true)
            builder.setTitle("Delete Patient")
            builder.setPositiveButton("Confirm",
                DialogInterface.OnClickListener { dialog, which ->
                    viewModel.deletePatient(thumbnailId)

                    Toast.makeText(context, "Patient deleted successfully!", Toast.LENGTH_SHORT).show()
                    findNavController().navigateUp()
                })
            builder.setNegativeButton(android.R.string.cancel,
                DialogInterface.OnClickListener { dialog, which -> })

            val dialog: AlertDialog = builder.create()
            dialog.show()

        }
        return binding.root


    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }





    }

