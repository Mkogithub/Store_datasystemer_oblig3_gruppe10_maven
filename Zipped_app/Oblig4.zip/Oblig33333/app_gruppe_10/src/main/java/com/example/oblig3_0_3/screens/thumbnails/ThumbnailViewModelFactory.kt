package com.example.oblig3_0_3.screens.thumbnails

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.oblig3_0_3.screens.albums.repository.Repository
import com.example.oblig3_0_3.screens.albums.AlbumViewModel

class ThumbnailViewModelFactory(private val repository: Repository): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ThumbnailViewModel(repository) as T
    }
}