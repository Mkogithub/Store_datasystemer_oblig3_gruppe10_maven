package com.example.oblig3_0_3.screens.albums

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oblig3_0_3.model.Patient
import com.example.oblig3_0_3.repository.Repository
import kotlinx.coroutines.launch
import retrofit2.Response

class AlbumViewModel(private val repository: Repository): ViewModel() {

    var myCustomAlbums: MutableLiveData<Response<List<Patient>>> = MutableLiveData()

    var myPatient: MutableLiveData<Response<Patient>> = MutableLiveData()

    fun getCustomAlbums(userId: String) {
        viewModelScope.launch {
            val response: Response<List<Patient>> = repository.getCustomAlbums(userId)
            myCustomAlbums.value = response
        }
    }


    suspend fun addPatient(patient: Patient) {
        val response: Response<Patient> = repository.addPatient(patient)
        myPatient.value = response

    }
}