package com.example.oblig3_0_3.model

data class Geo(
    val lat : String,
    val lng : String
)
