package com.example.oblig3_0_3.api

import com.example.oblig3_0_3.model.*
import retrofit2.Response
import retrofit2.http.*

interface GalleryApi {
    @GET("department/")
    suspend fun getDepartments(): Response<List<Department>>

    @GET("patients/")
    suspend fun getUsers(): Response<List<Patient>>

    @GET("department/getPatients/{userId}")
    suspend fun getCustomAlbums(
        @Path("userId") userId: String
    ): Response<List<Patient>>

    @POST("patients/addPatient")
    suspend fun addPatient(
        @Body patient:
        Patient): Response<Patient>


    @GET("photos")
    suspend fun getCustomThumbnails(
        @Query("albumId") albumId: Int
    ): Response<List<Photo>>


    @GET("photos/{thumbnailId}")
    suspend fun getCustomPhoto(
        @Path("thumbnailId") thumbnailId: Int
    ): Response<Photo>

    @PUT("photos/{thumbnailId}")
    suspend fun changeTitlePhoto(
        @Path("thumbnailId") thumbnailId: Int,
        @Body photo: Photo
    ): Response<Photo>

    @DELETE("photos/{thumbnailId}")
    suspend fun deletePhoto(
        @Path("thumbnailId") thumbnailId: Int,
    ): Response<Photo>

    @GET("albums")
    suspend fun getCustomAlbums2(
        @Query("userId") userId: Int,
        @QueryMap options: Map<String, String>
    ): Response<List<Album>>
}