package com.example.oblig3_0_3.util

class Constants {

    companion object {

        //your computers ipv4 address, or 10.0.0.2
        const val BASE_URL = "http://172.27.144.1:8080/api/"


    }
}