package com.example.oblig3_0_3.model

data class Company(
    val name : String,
    val catchPhrase : String,
    val bs : String
)
