package com.example.oblig3_0_3.screens.departments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.oblig3_0_3.adapter.MyOnClickListener
import com.example.oblig3_0_3.adapter.DepartmentAdapter
import com.example.oblig3_0_3.databinding.FragmentUserBinding
import com.example.oblig3_0_3.repository.Repository

class DepartmentFragment : Fragment(), MyOnClickListener{


    private var _binding: FragmentUserBinding? = null
    private val binding get() = _binding!!


    private lateinit var viewModel: UserViewModel
    private val departmentAdapter by lazy { DepartmentAdapter(this) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentUserBinding.inflate(inflater, container, false)

        setupRecyclerView()

        val repository = Repository()
        val viewModelFactory = UserViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory)[UserViewModel::class.java]
        viewModel.getUsers()
        viewModel.myUsers.observe(viewLifecycleOwner, Observer { response ->
            if (response.isSuccessful){
                response.body()?.let { departmentAdapter.setData(it) }
            }
            else {
                Log.d("Response", response.code().toString())
            }
        })
        return binding.root

    }

    private fun setupRecyclerView() {
        binding.userList.adapter = departmentAdapter
        binding.userList.layoutManager = LinearLayoutManager(context)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(position: Int) {
        var userId = departmentAdapter.userList[position].departmentId
        fun String.toSingleDigitList() = map {
            "$it".toIntOrNull()
        }.filterNotNull()
        val digits = userId.toSingleDigitList()
        val action = DepartmentFragmentDirections.actionDepartmentFragmentToAlbumFragment(digits[0])
        view?.findNavController()?.navigate(action)

        Log.d("Response", departmentAdapter.userList[position].departmentName)
    }
}
