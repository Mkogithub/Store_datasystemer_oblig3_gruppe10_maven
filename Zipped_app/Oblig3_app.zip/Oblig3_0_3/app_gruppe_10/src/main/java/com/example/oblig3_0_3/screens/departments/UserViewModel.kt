package com.example.oblig3_0_3.screens.departments

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oblig3_0_3.model.Department
import com.example.oblig3_0_3.repository.Repository
import kotlinx.coroutines.launch
import retrofit2.Response

class UserViewModel(private val repository: Repository): ViewModel() {

    var myUsers: MutableLiveData<Response<List<Department>>> = MutableLiveData()

    fun getUsers() {
        viewModelScope.launch {
            val response: Response<List<Department>> = repository.getDepartments()
            myUsers.value = response
        }
    }

}