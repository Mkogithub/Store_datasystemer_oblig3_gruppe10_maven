package com.example.oblig3_0_3.model;


data class Patient(

    val patientId: String,
    val created: String,
    var patientName: String,
    val modified: String,
    var symptoms: String,
    val description: String,
    val departmentId: String,
)
