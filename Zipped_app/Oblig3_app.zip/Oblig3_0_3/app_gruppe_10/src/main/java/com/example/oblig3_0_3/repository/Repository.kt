package com.example.oblig3_0_3.repository

import com.example.oblig3_0_3.api.RetrofitInstance
import com.example.oblig3_0_3.model.*
import retrofit2.Response

class Repository {

    suspend fun getUsers(): Response<List<Patient>> {
        return RetrofitInstance.api.getUsers()
    }

    suspend fun getDepartments(): Response<List<Department>> {
        return RetrofitInstance.api.getDepartments()
    }


    suspend fun getCustomAlbums(userId: String): Response<List<Patient>> {
        return RetrofitInstance.api.getCustomAlbums(userId)
    }

    suspend fun addPatient(patient: Patient): Response<Patient>{
        return RetrofitInstance.api.addPatient(patient)
    }

    suspend fun getCustomThumbnails(albumId: Int): Response<List<Photo>> {
        return RetrofitInstance.api.getCustomThumbnails(albumId)
    }

    suspend fun getCustomPhoto(thumbnailId: Int): Response<Photo> {
        return RetrofitInstance.api.getCustomPhoto(thumbnailId)
    }

    suspend fun changeTitlePhoto(thumbnailId: Int, photo: Photo): Response<Photo> {
        return RetrofitInstance.api.changeTitlePhoto(thumbnailId, photo)
    }

    suspend fun deletePhoto(thumbnailId: Int): Response<Photo> {
        return RetrofitInstance.api.deletePhoto(thumbnailId)
    }


    suspend fun getCustomAlbums2(userId: Int, options: Map<String, String>): Response<List<Album>> {
        return RetrofitInstance.api.getCustomAlbums2(userId, options)
    }
}